-- MySQL dump 10.13  Distrib 5.7.16, for Linux (x86_64)
--
-- Host: localhost    Database: idiorm
-- ------------------------------------------------------
-- Server version	5.7.16-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `album`
--

DROP TABLE IF EXISTS `album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album` (
  `album_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `created_at` int(50) NOT NULL,
  `album_name` text NOT NULL,
  PRIMARY KEY (`album_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
INSERT INTO `album` VALUES (1,5,1480634937,'this is it'),(2,5,1480830334,'Album 2'),(3,5,1481178808,'ewest'),(4,1,1481230431,'new');
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album_image`
--

DROP TABLE IF EXISTS `album_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album_id` varchar(11) NOT NULL,
  `image_id` varchar(11) NOT NULL,
  `created_at` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album_image`
--

LOCK TABLES `album_image` WRITE;
/*!40000 ALTER TABLE `album_image` DISABLE KEYS */;
INSERT INTO `album_image` VALUES (7,'2','35',1480741231),(8,'1','36',1480741234),(9,'1','37',1480741235),(10,'1','37',1480741325),(11,'%3Cbr%20','35',1481176543),(12,'4','32',1481230438),(13,'4','33',1481230438);
/*!40000 ALTER TABLE `album_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_queue`
--

DROP TABLE IF EXISTS `auth_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_queue` (
  `image_id` int(20) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_queue`
--

LOCK TABLES `auth_queue` WRITE;
/*!40000 ALTER TABLE `auth_queue` DISABLE KEYS */;
INSERT INTO `auth_queue` VALUES (14,1),(15,2);
/*!40000 ALTER TABLE `auth_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `path` varchar(100) NOT NULL,
  `user_id` int(50) NOT NULL,
  `created_at` int(50) NOT NULL,
  `updated_at` int(50) DEFAULT NULL,
  `auth` int(1) NOT NULL DEFAULT '0',
  `width` int(5) NOT NULL,
  `height` int(5) NOT NULL,
  `size_string` text NOT NULL,
  `mime_type` text NOT NULL,
  `user_image_name` text NOT NULL,
  `thumbnail` text NOT NULL,
  `watermark` text NOT NULL,
  `user_enabled` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
INSERT INTO `image` VALUES (30,'/users/images/raw_images/phprri8pc.jpg',1,1480366152,NULL,1,225,300,'width=\"225\" height=\"300\"','image/jpeg','a','/users/images/thumbnails/phpRri8pC.jpeg','/users/images/preview/phpRri8pC.jpeg',0),(31,'/users/images/raw_images/phpzmwlnw.jpg',1,1480366160,NULL,1,750,1064,'width=\"750\" height=\"1064\"','image/jpeg','a','/users/images/thumbnails/phpZmwlNW.jpeg','/users/images/preview/phpZmwlNW.jpeg',0),(32,'/users/images/raw_images/php9klfen.jpeg',1,1480366173,NULL,1,5184,3456,'width=\"5184\" height=\"3456\"','image/jpeg','a','/users/images/thumbnails/php9KlfeN.jpeg','/users/images/preview/php9KlfeN.jpeg',0),(33,'/users/images/raw_images/phpkuqqnn.jpg',1,1480366182,NULL,1,1920,1267,'width=\"1920\" height=\"1267\"','image/jpeg','a','/users/images/thumbnails/phpkUqQNn.jpeg','/users/images/preview/phpkUqQNn.jpeg',0),(34,'/users/images/raw_images/phpi7i3en.jpg',5,1480630331,NULL,1,480,360,'width=\"480\" height=\"360\"','image/jpeg','soulglo','/users/images/thumbnails/phpi7i3en.jpeg','/users/images/preview/phpi7i3en.jpeg',1),(35,'/users/images/raw_images/phppgh7qk.jpg',5,1480634219,NULL,1,2000,1000,'width=\"2000\" height=\"1000\"','image/jpeg','cloud','/users/images/thumbnails/phppgH7Qk.jpeg','/users/images/preview/phppgH7Qk.jpeg',1),(36,'/users/images/raw_images/phpw7mg10.jpg',5,1480699300,NULL,1,880,582,'width=\"880\" height=\"582\"','image/jpeg','pond','/users/images/thumbnails/phpW7MG10.jpeg','/users/images/preview/phpW7MG10.jpeg',1),(37,'/users/images/raw_images/php5llohu.jpg',5,1480699324,NULL,1,980,711,'width=\"980\" height=\"711\"','image/jpeg','horse','/users/images/thumbnails/php5lLohu.jpeg','/users/images/preview/php5lLohu.jpeg',1),(38,'/users/images/raw_images/phpdqgb0d.jpg',5,1481225280,NULL,1,600,450,'width=\"600\" height=\"450\"','image/jpeg','seaurchin','/users/images/thumbnails/phpDqgb0d.jpeg','/users/images/preview/phpDqgb0d.jpeg',1),(39,'/users/images/raw_images/php5sfvip.jpg',5,1481225318,NULL,1,970,647,'width=\"970\" height=\"647\"','image/jpeg','lambo','/users/images/thumbnails/php5SfvIp.jpeg','/users/images/preview/php5SfvIp.jpeg',1),(40,'/users/images/raw_images/phpiy0u4f.jpg',5,1481225355,NULL,1,480,360,'width=\"480\" height=\"360\"','image/jpeg','snowboard boots','/users/images/thumbnails/phpiY0u4F.jpeg','/users/images/preview/phpiY0u4F.jpeg',1),(41,'/users/images/raw_images/phpjgdxgi.jpg',5,1481225398,NULL,1,1100,619,'width=\"1100\" height=\"619\"','image/jpeg','shark','/users/images/thumbnails/phpjgDxgi.jpeg','/users/images/preview/phpjgDxgi.jpeg',1),(42,'/users/images/raw_images/php79yokz.jpg',5,1481225435,NULL,1,1920,1081,'width=\"1920\" height=\"1081\"','image/jpeg','zion','/users/images/thumbnails/php79yokz.jpeg','/users/images/preview/php79yokz.jpeg',1),(43,'/users/images/raw_images/phplkr5z2.jpg',5,1481225459,NULL,1,800,569,'width=\"800\" height=\"569\"','image/jpeg','desk','/users/images/thumbnails/phpLKr5z2.jpeg','/users/images/preview/phpLKr5z2.jpeg',1),(44,'/users/images/raw_images/phpr2sd8s.jpg',5,1481225506,NULL,1,3000,2000,'width=\"3000\" height=\"2000\"','image/jpeg','mtb','/users/images/thumbnails/phpr2SD8s.jpeg','/users/images/preview/phpr2SD8s.jpeg',1),(45,'/users/images/raw_images/phpzdv9d2.jpg',5,1481225655,NULL,1,600,391,'width=\"600\" height=\"391\"','image/jpeg','armchairs','/users/images/thumbnails/phpzdv9d2.jpeg','/users/images/preview/phpzdv9d2.jpeg',1),(46,'/users/images/raw_images/phpu7xqwc.jpg',5,1481225700,NULL,1,1000,750,'width=\"1000\" height=\"750\"','image/jpeg','green anemone','/users/images/thumbnails/phpU7XqWC.jpeg','/users/images/preview/phpU7XqWC.jpeg',1),(47,'/users/images/raw_images/phpmwnqbr.JPG',5,1481230378,NULL,1,2100,1266,'width=\"2100\" height=\"1266\"','image/jpeg','blueangels','/users/images/thumbnails/phpMWNqbr.JPG','/users/images/preview/phpMWNqbr.JPG',1),(48,'/users/images/raw_images/phpmnnoii.jpg',5,1481561934,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpMNnOII.jpeg','/users/images/preview/phpMNnOII.jpeg',1),(49,'/users/images/raw_images/phpj3f3su.jpg',5,1481562012,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpj3F3Su.jpeg','/users/images/preview/phpj3F3Su.jpeg',1),(50,'/users/images/raw_images/phpyhyz3n.jpg',5,1481562368,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpyHYz3n.jpeg','/users/images/preview/phpyHYz3n.jpeg',1),(51,'/users/images/raw_images/phpsx90km.jpg',5,1481562402,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpSx90Km.jpeg','/users/images/preview/phpSx90Km.jpeg',1),(52,'/users/images/raw_images/phpajokzj.jpg',5,1481563165,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpajOKzj.jpeg','/users/images/preview/phpajOKzj.jpeg',1),(53,'/users/images/raw_images/phpjstavn.jpg',5,1481563206,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpJSTavN.jpeg','/users/images/preview/phpJSTavN.jpeg',1),(54,'/users/images/raw_images/phpt85cnk.jpg',5,1481563246,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpT85cNk.jpeg','/users/images/preview/phpT85cNk.jpeg',1),(55,'/users/images/raw_images/phphhkxsj.jpg',5,1481563278,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phphhKXSj.jpeg','/users/images/preview/phphhKXSj.jpeg',1),(56,'/users/images/raw_images/phpvfhgqt.jpg',5,1481563313,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpvFHgQt.jpeg','/users/images/preview/phpvFHgQt.jpeg',1),(57,'/users/images/raw_images/phpx0pwrv.jpg',5,1481563325,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpx0pWRv.jpeg','/users/images/preview/phpx0pWRv.jpeg',1),(58,'/users/images/raw_images/phpgghfhw.jpg',5,1481563435,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpGGHFHW.jpeg','/users/images/preview/phpGGHFHW.jpeg',1),(59,'/users/images/raw_images/phpch07go.jpg',5,1481563483,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpCh07gO.jpeg','/users/images/preview/phpCh07gO.jpeg',1),(60,'/users/images/raw_images/phpgkt5at.jpg',5,1481563575,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpGkt5At.jpeg','/users/images/preview/phpGkt5At.jpeg',1),(61,'/users/images/raw_images/phpraktml.jpg',5,1481563668,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpRaKtMl.jpeg','/users/images/preview/phpRaKtMl.jpeg',1),(62,'/users/images/raw_images/phpi8p8l8.jpg',5,1481563697,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpi8P8L8.jpeg','/users/images/preview/phpi8P8L8.jpeg',1),(63,'/users/images/raw_images/phpxhsnoo.jpg',5,1481563710,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpxhSNoo.jpeg','/users/images/preview/phpxhSNoo.jpeg',1),(64,'/users/images/raw_images/phpaydxsn.jpg',5,1481563751,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpAYDxSN.jpeg','/users/images/preview/phpAYDxSN.jpeg',1),(65,'/users/images/raw_images/phpfg00dp.jpg',5,1481563773,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpFg00dP.jpeg','/users/images/preview/phpFg00dP.jpeg',1),(66,'/users/images/raw_images/phptxessu.jpg',5,1481563949,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phptxesSu.jpeg','/users/images/preview/phptxesSu.jpeg',1),(67,'/users/images/raw_images/phppjrbj6.jpg',5,1481563979,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpPJRBJ6.jpeg','/users/images/preview/phpPJRBJ6.jpeg',1),(68,'/users/images/raw_images/phpf88qza.jpg',5,1481564089,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpf88Qza.jpeg','/users/images/preview/phpf88Qza.jpeg',1),(69,'/users/images/raw_images/phpgfrbrf.jpg',5,1481564133,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpgfRBrf.jpeg','/users/images/preview/phpgfRBrf.jpeg',1),(70,'/users/images/raw_images/phpsbmxsy.jpg',5,1481564144,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpsbMXsY.jpeg','/users/images/preview/phpsbMXsY.jpeg',1),(71,'/users/images/raw_images/php43he6q.jpg',5,1481564173,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/php43he6q.jpeg','/users/images/preview/php43he6q.jpeg',1),(72,'/users/images/raw_images/phpakaiil.jpg',5,1481564266,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpakAiiL.jpeg','/users/images/preview/phpakAiiL.jpeg',1),(73,'/users/images/raw_images/phpwpoiah.jpg',5,1481564281,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpwPOiAH.jpeg','/users/images/preview/phpwPOiAH.jpeg',1),(74,'/users/images/raw_images/phpzm5i8e.jpg',5,1481564295,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpZM5i8E.jpeg','/users/images/preview/phpZM5i8E.jpeg',1),(75,'/users/images/raw_images/phpky9kbd.jpg',5,1481564309,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpkY9kBd.jpeg','/users/images/preview/phpkY9kBd.jpeg',1),(76,'/users/images/raw_images/phpeklzzm.jpg',5,1481564320,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpeKlZZm.jpeg','/users/images/preview/phpeKlZZm.jpeg',1),(77,'/users/images/raw_images/phpi4n6qq.jpg',5,1481564371,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpi4n6qQ.jpeg','/users/images/preview/phpi4n6qQ.jpeg',1),(78,'/users/images/raw_images/phpmulp1k.jpg',5,1481564396,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpMUlP1k.jpeg','/users/images/preview/phpMUlP1k.jpeg',1),(79,'/users/images/raw_images/php0e2pzk.jpg',5,1481564436,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/php0e2PzK.jpeg','/users/images/preview/php0e2PzK.jpeg',1),(80,'/users/images/raw_images/php2dqixl.jpg',5,1481564743,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/php2DQIXl.jpeg','/users/images/preview/php2DQIXl.jpeg',1),(81,'/users/images/raw_images/phpwafywo.jpg',5,1481564769,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpwafYWo.jpeg','/users/images/preview/phpwafYWo.jpeg',1),(82,'/users/images/raw_images/phpmnjclh.jpg',5,1481564889,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpmnJCLh.jpeg','/users/images/preview/phpmnJCLh.jpeg',1),(83,'/users/images/raw_images/phpmkvsfp.jpg',5,1481564924,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpmkvSfp.jpeg','/users/images/preview/phpmkvSfp.jpeg',1),(84,'/users/images/raw_images/phpwu49ez.jpg',5,1481565047,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpWU49eZ.jpeg','/users/images/preview/phpWU49eZ.jpeg',1),(85,'/users/images/raw_images/phpatfy2g.jpg',5,1481565067,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpaTFy2g.jpeg','/users/images/preview/phpaTFy2g.jpeg',1),(86,'/users/images/raw_images/phpdz7pqh.jpg',5,1481565211,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpDZ7PqH.jpeg','/users/images/preview/phpDZ7PqH.jpeg',1),(87,'/users/images/raw_images/php1yixqo.jpg',5,1481565266,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/php1yIXqo.jpeg','/users/images/preview/php1yIXqo.jpeg',1),(88,'/users/images/raw_images/php07f1gw.jpg',5,1481565291,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/php07F1GW.jpeg','/users/images/preview/php07F1GW.jpeg',1),(89,'/users/images/raw_images/phpfxq7np.jpg',5,1481566182,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpFxQ7NP.jpeg','/users/images/preview/phpFxQ7NP.jpeg',1),(90,'/users/images/raw_images/phppb7njz.jpg',5,1481566229,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phppB7nJZ.jpeg','/users/images/preview/phppB7nJZ.jpeg',1),(91,'/users/images/raw_images/php5l4yfw.jpg',5,1481566307,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/php5l4YFw.jpeg','/users/images/preview/php5l4YFw.jpeg',1),(92,'/users/images/raw_images/phpxkblcu.jpg',5,1481566443,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpXkbLcU.jpeg','/users/images/preview/phpXkbLcU.jpeg',1),(93,'/users/images/raw_images/phpqczgrx.jpg',5,1481566480,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpqczgrX.jpeg','/users/images/preview/phpqczgrX.jpeg',1),(94,'/users/images/raw_images/phpvo1y9y.jpg',5,1481566610,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpVO1Y9y.jpeg','/users/images/preview/phpVO1Y9y.jpeg',1),(95,'/users/images/raw_images/phpxnjay6.jpg',5,1481566673,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpxnjaY6.jpeg','/users/images/preview/phpxnjaY6.jpeg',1),(96,'/users/images/raw_images/phpywmsny.jpg',5,1481566696,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpyWmSnY.jpeg','/users/images/preview/phpyWmSnY.jpeg',1),(97,'/users/images/raw_images/phpbsnti7.jpg',5,1481566707,NULL,2,160,160,'width=\"160\" height=\"160\"','image/jpeg','ski','/users/images/thumbnails/phpBSnTi7.jpeg','/users/images/preview/phpBSnTi7.jpeg',1),(98,'/users/images/raw_images/phporgjox.jpg',1,1481567846,NULL,1,970,647,'width=\"970\" height=\"647\"','image/jpeg','lambo','/users/images/thumbnails/phpoRGJox.jpeg','/users/images/preview/phpoRGJox.jpeg',1),(99,'/users/images/raw_images/php6vrzhl.jpg',1,1481568646,NULL,1,480,360,'width=\"480\" height=\"360\"','image/jpeg','boots','/users/images/thumbnails/php6VrZhl.jpeg','/users/images/preview/php6VrZhl.jpeg',1),(100,'/users/images/raw_images/phpqzftuu.jpg',1,1481577538,NULL,1,3000,2000,'width=\"3000\" height=\"2000\"','image/jpeg','downhillmtb','/users/images/thumbnails/phpQzFtuU.jpeg','/users/images/preview/phpQzFtuU.jpeg',1),(101,'/users/images/raw_images/phpurrdzz.jpg',1,1481577775,NULL,1,1100,619,'width=\"1100\" height=\"619\"','image/jpeg','phillipines','/users/images/thumbnails/phpuRRDZz.jpeg','/users/images/preview/phpuRRDZz.jpeg',1),(102,'/users/images/raw_images/phpoqyych.jpg',1,1481577795,NULL,1,1100,619,'width=\"1100\" height=\"619\"','image/jpeg','phillipines','/users/images/thumbnails/phpOQyYch.jpeg','/users/images/preview/phpOQyYch.jpeg',1),(103,'/users/images/raw_images/phprepkxo.jpg',1,1481577967,NULL,1,880,582,'width=\"880\" height=\"582\"','image/jpeg','pond','/users/images/thumbnails/phprePKxo.jpeg','/users/images/preview/phprePKxo.jpeg',1);
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post` (
  `post_id` int(20) NOT NULL AUTO_INCREMENT,
  `author_id` int(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `body` text NOT NULL,
  `id` int(11) DEFAULT NULL,
  `tags` text,
  `post_type` int(11) DEFAULT NULL,
  `created_at` varchar(20) NOT NULL,
  `updated_at` int(20) DEFAULT NULL,
  `author_name` varchar(50) NOT NULL,
  PRIMARY KEY (`post_id`),
  KEY `author_id` (`author_id`),
  KEY `author_name` (`author_name`),
  CONSTRAINT `author_id` FOREIGN KEY (`author_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (4,1,'no tags','see if this works',NULL,'',NULL,'',0,''),(5,3,'this is a test post','lorem ipsum dolet',NULL,'latin',NULL,'',0,''),(6,3,'this is a test post 2','lorem dolet ipsum carpe diem',NULL,'latin',NULL,'',0,''),(7,3,'another','and another another',NULL,'yes',NULL,'',0,''),(8,4,'second test user','blah blah blah blah',NULL,'',NULL,'',0,''),(9,4,'another second','blah blah blah blah',NULL,'',NULL,'',0,''),(10,1,'test on timeq','time test',NULL,'',NULL,'',0,''),(11,1,'time','time',NULL,'',NULL,'1478992018',0,''),(12,1,'test post','another noather testttt',NULL,'boom',NULL,'1479073540',0,''),(13,1,'hope','hope',NULL,'pray',NULL,'1479336125',NULL,'Brian'),(14,1,'hope','hope',NULL,'pray',NULL,'1479336160',NULL,'Brian'),(15,1,'hope','hope',NULL,'pray',NULL,'1479336181',NULL,'Brian');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `user_id` int(8) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `avatar_path` text,
  `middle_name` text NOT NULL,
  `street_address` text NOT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `zip_code` text NOT NULL,
  `dob` varchar(10) NOT NULL,
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `avatar` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,'Brian','Moniz',NULL,'C','2175 Sidewinder Dr','Park City','UT','84060','05/08/1986',1,'/users/avatarsphpRFMNge.gif');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `store` (
  `user_id` int(20) NOT NULL,
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `main` text,
  `website` text,
  `intro` text,
  `created_at` int(30) NOT NULL,
  `updated_at` int(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
INSERT INTO `store` VALUES (5,9,NULL,'website demo','test',0,1480546998);
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `text` (`text`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (78,''),(128,'a'),(126,'add'),(77,'air bubbles'),(124,'another'),(129,'b'),(57,'boots'),(74,'cowboy'),(81,'dirt'),(60,'downhill mountain bike'),(71,'frozen lake'),(109,'harley'),(108,'hope'),(75,'horse'),(87,'island'),(113,'laces'),(80,'lambo'),(127,'many'),(83,'mountain'),(61,'mountain bike'),(59,'mtb'),(130,'no'),(65,'ocean'),(68,'ocean kayak'),(119,'once'),(115,'once?'),(120,'one'),(72,'pond'),(82,'pow'),(56,'snow'),(55,'snowboard boots'),(102,'something'),(118,'test'),(114,'testing'),(123,'this'),(125,'three'),(117,'trying to duplicate'),(116,'twice'),(121,'two'),(63,'whaleshark'),(76,'winter'),(122,'won'),(110,'yes');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_to_image`
--

DROP TABLE IF EXISTS `tag_to_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag_to_image` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `image_id` int(20) NOT NULL,
  `tag_id` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_to_image`
--

LOCK TABLES `tag_to_image` WRITE;
/*!40000 ALTER TABLE `tag_to_image` DISABLE KEYS */;
INSERT INTO `tag_to_image` VALUES (122,33,124),(123,98,125),(126,32,121),(127,32,125),(130,98,128),(131,98,129);
/*!40000 ALTER TABLE `tag_to_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  `salt` varchar(10) NOT NULL,
  `avatar` varchar(200) DEFAULT NULL,
  `first_name` text,
  `middle_name` text,
  `last_name` text,
  `dob` varchar(12) DEFAULT NULL,
  `level` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Brian','bcm811','62baffea5308be78831d703e8101157cf9c950c53d7bf80ac3810779c44ecf296ed6c','6ed6c','/users/avatars/php51pN7n.gif','Brian',NULL,NULL,NULL,1),(3,'test_account','test@test.com','9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08c595a','c595a',NULL,NULL,NULL,NULL,NULL,2),(4,'second_test','test2@test.com','9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08b0bfc','b0bfc',NULL,NULL,NULL,NULL,NULL,2),(5,'default','default@gmail.com','62baffea5308be78831d703e8101157cf9c950c53d7bf80ac3810779c44ecf29iÎ³îégü','iÎ³îégü','/users/avatars/phpjlM80a.png',NULL,NULL,NULL,NULL,2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-13 13:48:09
